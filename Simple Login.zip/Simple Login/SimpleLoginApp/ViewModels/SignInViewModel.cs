using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using SimpleLoginApp.Services;

namespace SimpleLoginApp.ViewModels
{
    public class SignInViewModel : INotifyPropertyChanged
    {
        private readonly AuthService _authService;
        private readonly Action<string, string> _showDashboard;
        private readonly Action _showSignUp;

        public SignInViewModel(
            AuthService authService,
            Action showSignUp,
            Action<string, string> showDashboard)
        {
            _authService = authService;
            _showSignUp = showSignUp;
            _showDashboard = showDashboard;

            LoginCommand = new RelayCommand(Login);
            SignUpCommand = new RelayCommand(_ => _showSignUp());
        }

        private string _username = "";
        public string Username
        {
            get => _username;
            set
            {
                _username = value;
                OnPropertyChanged();
            }
        }

        private string _password = "";
        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged();
            }
        }

        private string _message = "";
        public string Message
        {
            get => _message;
            set
            {
                _message = value;
                OnPropertyChanged();
            }
        }

        public ICommand LoginCommand { get; }
        public ICommand SignUpCommand { get; }

        private void Login(object? parameter)
        {
            if (string.IsNullOrWhiteSpace(Username) ||
                string.IsNullOrWhiteSpace(Password))
            {
                Message = "Enter your username and password.";
                return;
            }

            var user = _authService.Login(Username.Trim(), Password);

            if (user == null)
            {
                Message = "Invalid username or password.";
                return;
            }

            _showDashboard(user.Name, user.Role);
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(
            [CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName));
        }
    }
}