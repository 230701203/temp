
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace SimpleLoginApp.ViewModels
{
    public class DashboardViewModel : INotifyPropertyChanged
    {
        private readonly Action _logout;

        public DashboardViewModel(string name, string role, Action logout)
        {
            Name = name;
            Role = role;
            _logout = logout;
            LogoutCommand = new RelayCommand(_ => _logout());
        }

        public string Name { get; set; } = "";
        public string Role { get; set; } = "";

        public ICommand LogoutCommand { get; }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(
            [CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName));
        }
    }
}
