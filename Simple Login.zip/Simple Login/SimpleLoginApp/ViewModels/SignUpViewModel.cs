using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using SimpleLoginApp.Models;
using SimpleLoginApp.Services;

namespace SimpleLoginApp.ViewModels
{
    public class SignUpViewModel : INotifyPropertyChanged
    {
        private readonly AuthService _authService;
        private readonly Action _backToSignIn;

        public SignUpViewModel(AuthService authService, Action backToSignIn)
        {
            _authService = authService;
            _backToSignIn = backToSignIn;

            RegisterCommand = new RelayCommand(Register);
            BackCommand = new RelayCommand(_ => _backToSignIn());
        }

        private string _name = "";
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(); }
        }

        private string _username = "";
        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        private string _password = "";
        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        private string _confirmPassword = "";
        public string ConfirmPassword
        {
            get => _confirmPassword;
            set { _confirmPassword = value; OnPropertyChanged(); }
        }

        private string _role = "Employee";
        public string Role
        {
            get => _role;
            set { _role = value; OnPropertyChanged(); }
        }

        private string _message = "";
        public string Message
        {
            get => _message;
            set { _message = value; OnPropertyChanged(); }
        }

        public List<string> Roles { get; } =
            new List<string> { "Admin", "Manager", "Employee" };

        public ICommand RegisterCommand { get; }
        public ICommand BackCommand { get; }

        private void Register(object? parameter)
        {
            if (string.IsNullOrWhiteSpace(Name))
            {
                Message = "Name is not being received.";
                return;
            }

            if (string.IsNullOrWhiteSpace(Username))
            {
                Message = "Username is not being received.";
                return;
            }

            if (string.IsNullOrWhiteSpace(Password))
            {
                Message = "Password is not being received.";
                return;
            }

            if (string.IsNullOrWhiteSpace(ConfirmPassword))
            {
                Message = "Confirm Password is not being received.";
                return;
            }

            if (Password.Length < 8)
            {
                Message = "Password must contain at least 8 characters.";
                return;
            }

            if (Password != ConfirmPassword)
            {
                Message = "Passwords do not match.";
                return;
            }

            User user = new User
            {
                Name = Name.Trim(),
                Username = Username.Trim(),
                Password = Password,
                Role = Role
            };

            if (!_authService.Register(user))
            {
                Message = "Username already exists.";
                return;
            }

            Message = "Registration successful! Please sign in.";
            _backToSignIn();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(
            [CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;

        public RelayCommand(Action<object?> execute)
        {
            _execute = execute;
        }

        public bool CanExecute(object? parameter) => true;

        public void Execute(object? parameter) => _execute(parameter);

        public event EventHandler? CanExecuteChanged
        {
            add { }
            remove { }
        }
    }
}