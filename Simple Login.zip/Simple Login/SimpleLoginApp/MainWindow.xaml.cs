﻿
using System.Windows;
using SimpleLoginApp.Services;
using SimpleLoginApp.ViewModels;
using SimpleLoginApp.Views;

namespace SimpleLoginApp;

public partial class MainWindow : Window
{
    private readonly AuthService _authService = new AuthService();

    public MainWindow()
    {
        InitializeComponent();
        ShowSignIn();
    }

    public void ShowSignIn()
    {
        MainContent.Children.Clear();

        var view = new SignInView();

        view.DataContext = new SignInViewModel(
            _authService,
            ShowSignUp,
            ShowDashboard
        );

        MainContent.Children.Add(view);
    }

    public void ShowSignUp()
    {
        MainContent.Children.Clear();

        var view = new SignUpView();

        view.DataContext = new SignUpViewModel(
            _authService,
            ShowSignIn
        );

        MainContent.Children.Add(view);
    }

    public void ShowDashboard(string name, string role)
    {
        MainContent.Children.Clear();

        var dashboard = new DashboardView();

        dashboard.DataContext = new DashboardViewModel(
            name,
            role,
            ShowSignIn
        );

        MainContent.Children.Add(dashboard);
    }
}
