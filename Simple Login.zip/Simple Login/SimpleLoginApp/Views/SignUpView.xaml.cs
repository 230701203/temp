using System.Windows;
using System.Windows.Controls;
using SimpleLoginApp.ViewModels;

namespace SimpleLoginApp.Views
{
    public partial class SignUpView : UserControl
    {
        public SignUpView()
        {
            InitializeComponent();
        }

        private void PasswordInput_PasswordChanged(
            object sender, RoutedEventArgs e)
        {
            if (DataContext is SignUpViewModel viewModel)
            {
                viewModel.Password = PasswordInput.Password;
            }
        }

        private void ConfirmPasswordInput_PasswordChanged(
            object sender, RoutedEventArgs e)
        {
            if (DataContext is SignUpViewModel viewModel)
            {
                viewModel.ConfirmPassword = ConfirmPasswordInput.Password;
            }
        }
    }
}