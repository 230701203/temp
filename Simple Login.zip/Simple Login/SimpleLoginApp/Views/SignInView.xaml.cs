using System.Windows;
using System.Windows.Controls;
using SimpleLoginApp.ViewModels;

namespace SimpleLoginApp.Views
{
    public partial class SignInView : UserControl
    {
        public SignInView()
        {
            InitializeComponent();
        }

        private void PasswordInput_PasswordChanged(
            object sender, RoutedEventArgs e)
        {
            if (DataContext is SignInViewModel viewModel)
            {
                viewModel.Password = PasswordInput.Password;
            }
        }
    }
}