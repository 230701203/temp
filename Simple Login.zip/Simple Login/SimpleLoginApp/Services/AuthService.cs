using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using SimpleLoginApp.Models;

namespace SimpleLoginApp.Services
{
    public class AuthService
    {
        private static readonly string FolderPath =
            Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "SimpleLoginApp");

        private static readonly string FilePath =
            Path.Combine(FolderPath, "users.json");

        public static List<User> Users { get; private set; } =
            LoadUsers();

        private static List<User> LoadUsers()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    string json = File.ReadAllText(FilePath);

                    return JsonSerializer.Deserialize<List<User>>(json)
                           ?? new List<User>();
                }
            }
            catch (Exception)
            {
                // Start with an empty list if the file cannot be read.
            }

            return new List<User>();
        }

        private static void SaveUsers()
        {
            Directory.CreateDirectory(FolderPath);

            string json = JsonSerializer.Serialize(
                Users,
                new JsonSerializerOptions { WriteIndented = true });

            File.WriteAllText(FilePath, json);
        }

        public bool Register(User user)
        {
            if (Users.Any(u =>
                string.Equals(
                    u.Username.Trim(),
                    user.Username.Trim(),
                    StringComparison.OrdinalIgnoreCase)))
            {
                return false;
            }

            Users.Add(user);

            try
            {
                SaveUsers();
                return true;
            }
            catch (Exception)
            {
                Users.Remove(user);
                return false;
            }
        }

        public User? Login(string username, string password)
        {
            return Users.FirstOrDefault(u =>
                string.Equals(
                    u.Username.Trim(),
                    username.Trim(),
                    StringComparison.OrdinalIgnoreCase)
                && u.Password == password);
        }
    }
}
