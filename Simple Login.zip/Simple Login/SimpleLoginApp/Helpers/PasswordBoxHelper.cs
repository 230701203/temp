using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SimpleLoginApp.Helpers
{
    public static class PasswordBoxHelper
    {
        public static readonly DependencyProperty BoundPasswordProperty =
            DependencyProperty.RegisterAttached(
                "BoundPassword",
                typeof(string),
                typeof(PasswordBoxHelper),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnBoundPasswordChanged));

        private static readonly DependencyProperty IsUpdatingProperty =
            DependencyProperty.RegisterAttached(
                "IsUpdating",
                typeof(bool),
                typeof(PasswordBoxHelper),
                new PropertyMetadata(false));

        public static string GetBoundPassword(DependencyObject obj)
        {
            return (string)obj.GetValue(BoundPasswordProperty);
        }

        public static void SetBoundPassword(
            DependencyObject obj, string value)
        {
            obj.SetValue(BoundPasswordProperty, value);
        }

        private static bool GetIsUpdating(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsUpdatingProperty);
        }

        private static void SetIsUpdating(
            DependencyObject obj, bool value)
        {
            obj.SetValue(IsUpdatingProperty, value);
        }

        private static void OnBoundPasswordChanged(
            DependencyObject obj,
            DependencyPropertyChangedEventArgs e)
        {
            if (obj is not PasswordBox box)
                return;

            box.PasswordChanged -= PasswordChanged;

            string newPassword = e.NewValue as string ?? string.Empty;

            if (box.Password != newPassword)
            {
                SetIsUpdating(box, true);
                try
                {
                    box.Password = newPassword;
                }
                finally
                {
                    SetIsUpdating(box, false);
                }
            }

            box.PasswordChanged += PasswordChanged;
        }

        private static void PasswordChanged(
            object sender, RoutedEventArgs e)
        {
            if (sender is not PasswordBox box ||
                GetIsUpdating(box))
                return;

            try
            {
                SetIsUpdating(box, true);

                box.SetCurrentValue(
                    BoundPasswordProperty, box.Password);

                box.GetBindingExpression(BoundPasswordProperty)
                   ?.UpdateSource();
            }
            finally
            {
                SetIsUpdating(box, false);
            }
        }
    }
}